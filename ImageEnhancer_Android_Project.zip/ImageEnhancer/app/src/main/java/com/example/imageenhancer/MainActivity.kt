package com.example.imageenhancer

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.imageenhancer.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var originalBitmap: Bitmap? = null
    private var resultBitmap: Bitmap? = null
    private lateinit var upscaler: ImageUpscaler
    private val faceEnhancer = FaceEnhancer()

    companion object {
        const val REQUEST_IMAGE_PICK = 100
        const val REQUEST_PERMISSION = 200
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        upscaler = ImageUpscaler(this)

        binding.btnSelect.setOnClickListener {
            checkPermissionAndPickImage()
        }

        binding.btnEnhance.setOnClickListener {
            processImage()
        }

        binding.btnSave.setOnClickListener {
            saveImage()
        }
    }

    private fun checkPermissionAndPickImage() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            Manifest.permission.READ_MEDIA_IMAGES
        else
            Manifest.permission.READ_EXTERNAL_STORAGE

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            pickImage()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(permission), REQUEST_PERMISSION)
        }
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_IMAGE_PICK)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSION && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            pickImage()
        } else {
            Toast.makeText(this, "Permission required to select images", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_PICK && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            val inputStream = contentResolver.openInputStream(uri)
            originalBitmap = BitmapFactory.decodeStream(inputStream)
            binding.ivOriginal.setImageBitmap(originalBitmap)
            binding.ivEnhanced.setImageResource(android.R.color.darker_gray)
            binding.btnEnhance.isEnabled = true
            binding.btnSave.isEnabled = false
            binding.tvStatus.text = "Image loaded. Select features and tap Enhance."
            resultBitmap = null
        }
    }

    private fun processImage() {
        val bmp = originalBitmap ?: return

        binding.progressBar.visibility = View.VISIBLE
        binding.btnEnhance.isEnabled = false
        binding.btnSave.isEnabled = false
        binding.tvStatus.text = "Processing..."

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                var result = bmp.copy(Bitmap.Config.ARGB_8888, true)

                withContext(Dispatchers.Main) { binding.tvStatus.text = "Removing noise..." }
                if (binding.cbDenoise.isChecked) {
                    result = ImageProcessor.denoise(result)
                }

                withContext(Dispatchers.Main) { binding.tvStatus.text = "Correcting colors..." }
                if (binding.cbColor.isChecked) {
                    result = ImageProcessor.colorCorrect(result)
                }

                withContext(Dispatchers.Main) { binding.tvStatus.text = "AI upscaling to HD..." }
                if (binding.cbUpscale.isChecked) {
                    result = upscaler.upscale(result)
                }

                withContext(Dispatchers.Main) { binding.tvStatus.text = "Enhancing faces..." }
                if (binding.cbFaces.isChecked) {
                    result = suspendCoroutine { cont ->
                        faceEnhancer.enhanceFaces(result) { enhanced ->
                            cont.resume(enhanced)
                        }
                    }
                }

                resultBitmap = result

                withContext(Dispatchers.Main) {
                    binding.ivEnhanced.setImageBitmap(result)
                    binding.progressBar.visibility = View.GONE
                    binding.btnSave.isEnabled = true
                    binding.btnEnhance.isEnabled = true
                    binding.tvStatus.text = "Done! Tap Save to keep the result."
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    binding.btnEnhance.isEnabled = true
                    binding.tvStatus.text = "Error: ${e.message}"
                    Toast.makeText(this@MainActivity, "Processing failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun saveImage() {
        val bitmap = resultBitmap ?: return

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val filename = "enhanced_${System.currentTimeMillis()}.jpg"
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ImageEnhancer")
                    }
                }

                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                uri?.let {
                    contentResolver.openOutputStream(it)?.use { stream ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                    }
                }

                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Saved to Pictures/ImageEnhancer!", Toast.LENGTH_SHORT).show()
                    binding.tvStatus.text = "Image saved to gallery."
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
