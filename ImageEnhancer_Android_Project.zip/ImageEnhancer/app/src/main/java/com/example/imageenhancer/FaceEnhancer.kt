package com.example.imageenhancer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions

class FaceEnhancer {

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setMinFaceSize(0.05f)
            .build()
    )

    /**
     * Detect all faces in the bitmap, apply targeted sharpening+denoising
     * to each face region, then blend back into the full image.
     */
    fun enhanceFaces(bitmap: Bitmap, onComplete: (Bitmap) -> Unit) {
        val inputImage = InputImage.fromBitmap(bitmap, 0)

        detector.process(inputImage)
            .addOnSuccessListener { faces ->
                if (faces.isEmpty()) {
                    Log.d("FaceEnhancer", "No faces detected")
                    onComplete(bitmap)
                    return@addOnSuccessListener
                }

                Log.d("FaceEnhancer", "Detected ${faces.size} face(s)")

                val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
                val canvas = Canvas(result)

                for (face in faces) {
                    val box = face.boundingBox

                    // Add padding around detected face region
                    val padding = (box.width() * 0.15).toInt()
                    val paddedBox = Rect(
                        maxOf(0, box.left - padding),
                        maxOf(0, box.top - padding),
                        minOf(bitmap.width, box.right + padding),
                        minOf(bitmap.height, box.bottom + padding)
                    )

                    if (paddedBox.width() <= 0 || paddedBox.height() <= 0) continue

                    try {
                        // Crop face region
                        val faceBitmap = Bitmap.createBitmap(
                            bitmap,
                            paddedBox.left, paddedBox.top,
                            paddedBox.width(), paddedBox.height()
                        )

                        // Apply denoise then sharpen on face region
                        val enhanced = ImageProcessor.sharpen(
                            ImageProcessor.denoise(faceBitmap),
                            strength = 1.3
                        )

                        // Paint enhanced face back onto canvas
                        canvas.drawBitmap(
                            enhanced,
                            null,
                            android.graphics.RectF(
                                paddedBox.left.toFloat(),
                                paddedBox.top.toFloat(),
                                paddedBox.right.toFloat(),
                                paddedBox.bottom.toFloat()
                            ),
                            null
                        )
                    } catch (e: Exception) {
                        Log.e("FaceEnhancer", "Failed to enhance face: ${e.message}")
                    }
                }

                onComplete(result)
            }
            .addOnFailureListener { e ->
                Log.e("FaceEnhancer", "Face detection failed: ${e.message}")
                onComplete(bitmap) // Return original on failure
            }
    }
}
