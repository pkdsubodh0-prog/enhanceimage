package com.example.imageenhancer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.support.common.FileUtil

class ImageUpscaler(context: Context) {

    private var interpreter: Interpreter? = null
    private val INPUT_SIZE = 256
    private val SCALE_FACTOR = 4

    init {
        try {
            val model = FileUtil.loadMappedFile(context, "realesrgan.tflite")
            val options = Interpreter.Options()
            try {
                options.addDelegate(GpuDelegate())
                Log.d("ImageUpscaler", "Using GPU delegate")
            } catch (e: Exception) {
                Log.d("ImageUpscaler", "GPU not available, using CPU: ${e.message}")
                options.setNumThreads(4)
            }
            interpreter = Interpreter(model, options)
            Log.d("ImageUpscaler", "Model loaded successfully")
        } catch (e: Exception) {
            Log.e("ImageUpscaler", "Failed to load model: ${e.message}")
            // App still works — upscaling will use bicubic fallback
        }
    }

    fun upscale(inputBitmap: Bitmap): Bitmap {
        val interp = interpreter
        if (interp == null) {
            // Fallback: bicubic upscale x4 if model not loaded
            Log.w("ImageUpscaler", "Model not available, using bicubic upscale")
            val w = inputBitmap.width * SCALE_FACTOR
            val h = inputBitmap.height * SCALE_FACTOR
            return Bitmap.createScaledBitmap(inputBitmap, w, h, true)
        }

        return try {
            // Resize input to model's expected size
            val resized = Bitmap.createScaledBitmap(inputBitmap, INPUT_SIZE, INPUT_SIZE, true)

            // Convert bitmap to float array [1, H, W, 3], normalized 0-1
            val inputArray = Array(1) { Array(INPUT_SIZE) { Array(INPUT_SIZE) { FloatArray(3) } } }
            for (y in 0 until INPUT_SIZE) {
                for (x in 0 until INPUT_SIZE) {
                    val pixel = resized.getPixel(x, y)
                    inputArray[0][y][x][0] = Color.red(pixel) / 255f
                    inputArray[0][y][x][1] = Color.green(pixel) / 255f
                    inputArray[0][y][x][2] = Color.blue(pixel) / 255f
                }
            }

            // Prepare output array [1, H*4, W*4, 3]
            val outputSize = INPUT_SIZE * SCALE_FACTOR
            val outputArray = Array(1) { Array(outputSize) { Array(outputSize) { FloatArray(3) } } }

            interp.run(inputArray, outputArray)

            // Convert output back to Bitmap
            val outputBitmap = Bitmap.createBitmap(outputSize, outputSize, Bitmap.Config.ARGB_8888)
            for (y in 0 until outputSize) {
                for (x in 0 until outputSize) {
                    val r = (outputArray[0][y][x][0] * 255).toInt().coerceIn(0, 255)
                    val g = (outputArray[0][y][x][1] * 255).toInt().coerceIn(0, 255)
                    val b = (outputArray[0][y][x][2] * 255).toInt().coerceIn(0, 255)
                    outputBitmap.setPixel(x, y, Color.rgb(r, g, b))
                }
            }
            outputBitmap
        } catch (e: Exception) {
            Log.e("ImageUpscaler", "Upscaling failed: ${e.message}")
            // Fallback to bicubic
            val w = inputBitmap.width * SCALE_FACTOR
            val h = inputBitmap.height * SCALE_FACTOR
            Bitmap.createScaledBitmap(inputBitmap, w, h, true)
        }
    }
}
