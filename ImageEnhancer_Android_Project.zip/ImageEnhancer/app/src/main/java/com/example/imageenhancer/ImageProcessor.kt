package com.example.imageenhancer

import android.graphics.Bitmap
import android.util.Log
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo

object ImageProcessor {

    /**
     * Remove noise from an image using Non-Local Means Denoising.
     * Also applies light sharpening after denoising.
     */
    fun denoise(bitmap: Bitmap): Bitmap {
        return try {
            val src = Mat()
            Utils.bitmapToMat(bitmap, src)
            Imgproc.cvtColor(src, src, Imgproc.COLOR_RGBA2RGB)

            val denoised = Mat()
            // h=8: filter strength. Higher = more smoothing but loses some detail
            Photo.fastNlMeansDenoisingColored(src, denoised, 8f, 8f, 7, 21)

            // Apply light sharpening after denoising
            val blurred = Mat()
            Imgproc.GaussianBlur(denoised, blurred, Size(0.0, 0.0), 2.0)
            val sharpened = Mat()
            Core.addWeighted(denoised, 1.3, blurred, -0.3, 0.0, sharpened)

            Imgproc.cvtColor(sharpened, sharpened, Imgproc.COLOR_RGB2RGBA)
            val resultBitmap = Bitmap.createBitmap(sharpened.cols(), sharpened.rows(), Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(sharpened, resultBitmap)
            resultBitmap
        } catch (e: Exception) {
            Log.e("ImageProcessor", "Denoise failed: ${e.message}")
            bitmap
        }
    }

    /**
     * Color correction: adjust brightness, contrast, and saturation.
     * Default values are tuned for typical underexposed/dull photos.
     */
    fun colorCorrect(
        bitmap: Bitmap,
        brightness: Double = 5.0,
        contrast: Double = 1.15,
        saturation: Double = 1.25
    ): Bitmap {
        return try {
            val src = Mat()
            Utils.bitmapToMat(bitmap, src)
            Imgproc.cvtColor(src, src, Imgproc.COLOR_RGBA2RGB)

            // Brightness + contrast: dst = src * contrast + brightness
            val adjusted = Mat()
            src.convertTo(adjusted, -1, contrast, brightness)

            // Saturation boost via HSV
            val hsv = Mat()
            Imgproc.cvtColor(adjusted, hsv, Imgproc.COLOR_RGB2HSV)

            val channels = ArrayList<Mat>()
            Core.split(hsv, channels)

            // Channel 1 = Saturation
            Core.multiply(channels[1], Scalar(saturation), channels[1])
            Core.normalize(channels[1], channels[1], 0.0, 255.0, Core.NORM_MINMAX)

            Core.merge(channels, hsv)
            val result = Mat()
            Imgproc.cvtColor(hsv, result, Imgproc.COLOR_HSV2RGB)
            Imgproc.cvtColor(result, result, Imgproc.COLOR_RGB2RGBA)

            val resultBitmap = Bitmap.createBitmap(result.cols(), result.rows(), Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(result, resultBitmap)
            resultBitmap
        } catch (e: Exception) {
            Log.e("ImageProcessor", "Color correction failed: ${e.message}")
            bitmap
        }
    }

    /**
     * Apply sharpening only (without denoising).
     * Used for targeted face enhancement.
     */
    fun sharpen(bitmap: Bitmap, strength: Double = 1.4): Bitmap {
        return try {
            val src = Mat()
            Utils.bitmapToMat(bitmap, src)

            val blurred = Mat()
            Imgproc.GaussianBlur(src, blurred, Size(0.0, 0.0), 3.0)

            val sharpened = Mat()
            Core.addWeighted(src, strength, blurred, -(strength - 1.0), 0.0, sharpened)

            val resultBitmap = Bitmap.createBitmap(sharpened.cols(), sharpened.rows(), Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(sharpened, resultBitmap)
            resultBitmap
        } catch (e: Exception) {
            Log.e("ImageProcessor", "Sharpen failed: ${e.message}")
            bitmap
        }
    }
}
